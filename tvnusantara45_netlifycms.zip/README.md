# TV NUSANTARA 45 — Netlify + Netlify CMS (Siap Pakai)

Hai Sugiarto Kasirin — ini paket sederhana untuk memasang Netlify CMS di situs Netlify kamu.

Langkah singkat untuk pakai:
1. Buat repository di GitHub (misal `tvnusantara45`) dan upload seluruh isi dari folder ini ke repo.
2. Di Netlify, buat site baru dan hubungkan ke repository GitHub kamu.
3. Di Netlify dashboard → **Identity** → Klik **Enable Identity**.
4. Setelah Identity aktif, buka **Services** → **Enable Git Gateway**.
5. Buka `https://<your-site>.netlify.app/admin` → klik **Invite** atau daftar dengan email → login.
6. Sekarang kamu bisa membuat berita di CMS. Koleksi sudah tersedia: **Berita** dengan kategori `Nasional`, `Daerah`, `Hiburan`.

Catatan:
- Template ini sangat sederhana (HTML statis). Untuk produksi biasanya gunakan static site generator (Hugo/Jekyll) agar konten markdown dirender otomatis.
- Jika kamu mau, aku bisa bantu langkah-per-langkah upload ke GitHub dan hubungkan Netlify langsung.

Selamat! 🎉
